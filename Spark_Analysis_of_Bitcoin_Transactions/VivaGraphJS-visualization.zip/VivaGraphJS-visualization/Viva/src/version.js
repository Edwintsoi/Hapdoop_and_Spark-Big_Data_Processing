// todo: this should be generated at build time.
module.exports = '0.8.1';
